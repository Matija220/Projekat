/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exception;

public class NeuspesnoDodavanjeKnjigeException extends Exception {

    public NeuspesnoDodavanjeKnjigeException() {
        super();
    }

    public NeuspesnoDodavanjeKnjigeException(String message) {
        super(message);
    }

    public NeuspesnoDodavanjeKnjigeException(String message, Throwable cause) {
        super(message, cause);
    }

    public NeuspesnoDodavanjeKnjigeException(Throwable cause) {
        super(cause);
    }
}
