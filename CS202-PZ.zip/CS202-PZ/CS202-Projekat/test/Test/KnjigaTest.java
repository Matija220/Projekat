package Test;

import klase.Knjiga;
import Exception.NeuspesnoDodavanjeKnjigeException;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class KnjigaTest {

    @BeforeClass
    public static void inicijalizacija() {
        // Inicijalizacija, može biti prazna ako ne koristite JavaFX
    }

    @Test
    public void testDodajKnjigu() {
        Knjiga knjiga = new Knjiga("Idemo", "Natasa", "Lekcija", 2040);

        try {
            knjiga.dodajKnjigu();
            assertTrue(knjiga.getId() > 0); // Proveravamo da li je dodato u bazu i dodeljeno ID
        } catch (NeuspesnoDodavanjeKnjigeException e) {
            fail("Ne očekujemo izuzetak prilikom dodavanja knjige.");
        }
    }

   

    @Test(expected = NeuspesnoDodavanjeKnjigeException.class)
    public void testDodajKnjiguSaGreskom() throws NeuspesnoDodavanjeKnjigeException {
        Knjiga knjiga = new Knjiga("Naslov", "Autor", "Zanr", 200);
        knjiga.setId(1); // Postavljamo ID, što bi trebalo da izazove grešku prilikom dodavanja.

        knjiga.dodajKnjigu();
    }
}
