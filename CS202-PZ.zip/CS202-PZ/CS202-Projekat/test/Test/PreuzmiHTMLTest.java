package Test;

import PreuzimanjeSaStranice.PreuzmiHTML;


import static org.junit.Assert.*;

import org.junit.Test;
import java.io.IOException;

public class PreuzmiHTMLTest {

    @Test
    public void testPreuzmiHTMLSuccess() {
        try {
            String html = PreuzmiHTML.preuzmiHTML("https://www.example.com");
            assertNotNull(html);
            assertFalse(html.isEmpty());
        } catch (IOException e) {
            fail("Exception thrown when not expected: " + e.getMessage());
        }
    }

    @Test(expected = IOException.class)
    public void testPreuzmiHTMLIOException() throws IOException {
        PreuzmiHTML.preuzmiHTML("https://nonexistentwebsite123.com");
    }

    @Test(expected = IOException.class)
    public void testPreuzmiHTMLNullURL() throws IOException {
        PreuzmiHTML.preuzmiHTML(null);
    }
}

