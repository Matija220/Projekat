/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Moduli;

import Moduli.RegistracijaModulFX;
import Moduli.LoginModulFX;
import Exception.PraznoPoljeException;
import Exception.NeuspesnaRegistracijaException;
import Interfejsi.BibliotekarInterfejs;
import Interfejsi.CitalacInterfejsFX;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class GlavnaAplikacijaFX extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Biblioteka Aplikacija");

        GridPane gridPane = createGridPane();
        Button prijaviSeButton = new Button("Prijavi se");
        Button registrujSeButton = new Button("Registruj se");

        prijaviSeButton.setOnAction(e -> prikaziPrijavu());
        registrujSeButton.setOnAction(e -> prikaziRegistraciju());

        gridPane.add(registrujSeButton, 0, 2);
        gridPane.add(prijaviSeButton, 1, 2);

        Scene scene = new Scene(gridPane, 400, 200);
        

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private GridPane createGridPane() {
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setVgap(8);
        gridPane.setHgap(10);
        

        return gridPane;
    }

    private void prikaziRegistraciju() {
        Stage registracijaProzor = new Stage();
        registracijaProzor.setTitle("Registracija");

        GridPane panel = createGridPane();
        panel.setVgap(8);

        Label labelaIme = new Label("Ime:");
        TextField poljeIme = new TextField();

        Label labelaPrezime = new Label("Prezime:");
        TextField poljePrezime = new TextField();

        Label labelaEmail = new Label("Email:");
        TextField poljeEmail = new TextField();

        Label labelaSifra = new Label("Šifra:");
        PasswordField poljeSifra = new PasswordField();

        Button dugmeRegistrujSe = new Button("Registruj se");

        panel.add(labelaIme, 0, 0);
        panel.add(poljeIme, 1, 0);
        panel.add(labelaPrezime, 0, 1);
        panel.add(poljePrezime, 1, 1);
        panel.add(labelaEmail, 0, 2);
        panel.add(poljeEmail, 1, 2);
        panel.add(labelaSifra, 0, 3);
        panel.add(poljeSifra, 1, 3);
        panel.add(dugmeRegistrujSe, 1, 4);

        dugmeRegistrujSe.setOnAction(e -> {
            String ime = poljeIme.getText();
            String prezime = poljePrezime.getText();
            String email = poljeEmail.getText();
            String sifra = poljeSifra.getText();

            boolean uspesnaRegistracija = false; // Postavite podrazumevanu vrednost

            try {
                uspesnaRegistracija = RegistracijaModulFX.registrujCitaoca(ime, prezime, email, sifra);
            } catch (NeuspesnaRegistracijaException | PraznoPoljeException ex) {
                Logger.getLogger(GlavnaAplikacijaFX.class.getName()).log(Level.SEVERE, null, ex);
            }

            if (uspesnaRegistracija) {
                prikaziInformaciju("Uspešna registracija!");
                registracijaProzor.close();
            } else {
                prikaziGresku("Registracija nije uspela.");
            }
        });

        Scene scene = new Scene(panel, 400, 200);
        registracijaProzor.setScene(scene);
        registracijaProzor.show();
    }

    private void prikaziPrijavu() {
        Stage prijavaProzor = new Stage();
        prijavaProzor.setTitle("Prijava");

        GridPane panel = createGridPane();
        panel.setVgap(8);

        Label labelaEmail = new Label("Email:");
        TextField poljeEmail = new TextField();

        Label labelaSifra = new Label("Šifra:");
        PasswordField poljeSifra = new PasswordField();

        Button dugmePrijaviSe = new Button("Prijavi se");

        panel.add(labelaEmail, 0, 0);
        panel.add(poljeEmail, 1, 0);
        panel.add(labelaSifra, 0, 1);
        panel.add(poljeSifra, 1, 1);
        panel.add(dugmePrijaviSe, 1, 2);

        dugmePrijaviSe.setOnAction(e -> {
            String email = poljeEmail.getText();
            String sifra = poljeSifra.getText();

            String uloga = LoginModul.prijaviKorisnika(email, sifra);

            if (uloga != null) {
                prikaziInformaciju("Uspešna prijava kao " + uloga);
                prijavaProzor.close();

                Stage glavniProzor = null;
                if ("bibliotekar".equals(uloga)) {
                    glavniProzor = new Stage();
                    BibliotekarInterfejs bibliotekarProzor = new BibliotekarInterfejs();
                    bibliotekarProzor.start(glavniProzor);
                } else {
                    glavniProzor = new Stage();
                    CitalacInterfejsFX citalacProzor = new CitalacInterfejsFX();
                    citalacProzor.start(glavniProzor);
                }

                glavniProzor.setOnCloseRequest(event -> System.exit(0));
                glavniProzor.show();
            } else {
                prikaziGresku("Neuspešna prijava.");
            }
        });

        Scene scene = new Scene(panel, 400, 150);
        prijavaProzor.setScene(scene);
        prijavaProzor.show();
    }

    private static void prikaziInformaciju(String poruka) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informacija");
        alert.setHeaderText(null);
        alert.setContentText(poruka);
        alert.showAndWait();
    }

    private static void prikaziGresku(String poruka) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Greška");
        alert.setHeaderText(null);
        alert.setContentText(poruka);
        alert.showAndWait();
    }
}
