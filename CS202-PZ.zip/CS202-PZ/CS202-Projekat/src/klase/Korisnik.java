
package klase;

public class Korisnik {
    private int id;
    private String ime;
    private String prezime;
    private String email;
    private String sifra;
    private String uloga;

    public Korisnik(int id, String ime, String prezime, String email, String sifra, String uloga) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.email = email;
        this.sifra = sifra;
        this.uloga = uloga;
    }

    public int getId() {
        return id;
    }

    public String getIme() {
        return ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public String getEmail() {
        return email;
    }

    public String getSifra() {
        return sifra;
    }

    public String getUloga() {
        return uloga;
    }

    @Override
    public String toString() {
        return "Korisnik{" +
                "id=" + id +
                ", ime='" + ime + '\'' +
                ", prezime='" + prezime + '\'' +
                ", email='" + email + '\'' +
                ", sifra='" + sifra + '\'' +
                ", uloga='" + uloga + '\'' +
                '}';
    }
}

