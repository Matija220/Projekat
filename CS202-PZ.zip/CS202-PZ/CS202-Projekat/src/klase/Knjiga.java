/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package klase;

import Exception.NeuspesnoCitavanjeIzBazeException;
import Exception.NeuspesnoDodavanjeKnjigeException;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import java.sql.*;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Knjiga {

    private static final String URL = "jdbc:mysql://localhost:3306/gradske_biblioteke";
    private static final String KORISNICKO_IME = "root";
    private static final String SIFRA = "";

    private int id;
    private String naslov;
    private String autor;
    private String zanr;
    private int brojStrana;
    private int ocena;
    private String komentar;

    public Knjiga(String naslov, String autor, String zanr, int brojStrana, int ocena, String komentar) {
        this.naslov = naslov;
        this.autor = autor;
        this.zanr = zanr;
        this.brojStrana = brojStrana;
        this.ocena = ocena;
        this.komentar = komentar;
    }

    public Knjiga(int id, String naslov, String autor, String zanr, int brojStrana, int ocena, String komentar) {
        this.id = id;
        this.naslov = naslov;
        this.autor = autor;
        this.zanr = zanr;
        this.brojStrana = brojStrana;
        this.ocena = ocena;
        this.komentar = komentar;
    }

    public Knjiga(String naslov, String autor, String zanr, int brojStrana) {
        this.naslov = naslov;
        this.autor = autor;
        this.zanr = zanr;
        this.brojStrana = brojStrana;
    }

    public Knjiga(int id, String naslov, String autor, String zanr, int brojStrana) {
        this.id = id;
        this.naslov = naslov;
        this.autor = autor;
        this.zanr = zanr;
        this.brojStrana = brojStrana;
    }

    public Knjiga(String naslov, String autor, String zanr, int brojStrana, int ocena) {
        this.naslov = naslov;
        this.autor = autor;
        this.zanr = zanr;
        this.brojStrana = brojStrana;
        this.ocena = ocena;
    }

    public Knjiga(int id, String naslov, String autor, String zanr, int brojStrana, int ocena) {
        this.id = id;
        this.naslov = naslov;
        this.autor = autor;
        this.zanr = zanr;
        this.brojStrana = brojStrana;
        this.ocena = ocena;
    }

    public String getNaslov() {
        return naslov;
    }

    public void setNaslov(String naslov) {
        this.naslov = naslov;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getZanr() {
        return zanr;
    }

    public void setZanr(String zanr) {
        this.zanr = zanr;
    }

    public int getBrojStrana() {
        return brojStrana;
    }

    public void setBrojStrana(int brojStrana) {
        this.brojStrana = brojStrana;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKomentar() {
        return komentar;
    }

    public void setKomentar(String komentar) {
        this.komentar = komentar;
    }

    @Override
    public String toString() {
        return "Knjiga{" + "id=" + id + ", naslov=" + naslov + ", autor=" + autor + ", zanr=" + zanr + ", brojStrana=" + brojStrana + ", ocena=" + ocena + '}';
    }

    private void prikaziGresku(String poruka) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Greška");
        alert.setHeaderText(null);
        alert.setContentText(poruka);
        alert.showAndWait();
    }
}
