-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2024 at 04:41 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gradske_biblioteke`
--

-- --------------------------------------------------------

--
-- Table structure for table `knjige`
--

CREATE TABLE `knjige` (
  `id` int(11) NOT NULL,
  `naslov` varchar(255) NOT NULL,
  `autor` varchar(255) NOT NULL,
  `zanr` varchar(100) DEFAULT NULL,
  `broj_strana` int(11) DEFAULT NULL,
  `ocena_id` int(11) DEFAULT NULL,
  `komentari_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `knjige`
--

INSERT INTO `knjige` (`id`, `naslov`, `autor`, `zanr`, `broj_strana`, `ocena_id`, `komentari_id`) VALUES
(1, 'Igor', 'Milan', 'Medicina', 500, NULL, NULL),
(3, 'Sandra', 'Okobo', 'fudbal', 100, NULL, NULL),
(4, 'jos', 'davno', 'nisi', 1010, NULL, NULL),
(5, 'Naslov', 'Autor', 'Zanr', 200, NULL, NULL),
(22, 'Idemo', 'Natasa', 'Lekcija', 2040, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `komentari`
--

CREATE TABLE `komentari` (
  `id` int(11) NOT NULL,
  `tekst` text NOT NULL,
  `id_knjige` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE `korisnici` (
  `id` int(11) NOT NULL,
  `ime` varchar(50) NOT NULL,
  `prezime` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `sifra` varchar(255) NOT NULL,
  `uloga` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`id`, `ime`, `prezime`, `email`, `sifra`, `uloga`) VALUES
(1, 'aaa', 'vvvvv', 'Bibliotekar@gmail.com', 'Bibliotekar1', 'bibliotekar'),
(3, 'Ivica', 'Rukovic', 'Ivi@gmail.com', 'Pobednik234', 'citalac'),
(4, 'Nikola', 'Simic', 'Nikolas@gmail.com', 'Dugasifra', 'citalac'),
(5, 'sara', 'milic', 'sama@gmail.rs', 'malasara12', 'citalac'),
(6, 'milan', 'kostic', 'milan22@gmail.com', 'milank22', 'citalac'),
(7, 'Milan', 'Zoric', 'Milan456@gmail.com', 'Nulan456', 'citalac'),
(9, 'Andrija', 'Golubovic', 'Andrija5@gmail.com', 'Andrija321', 'citalac'),
(10, 'Matija', 'Vucic', 'Vucko999@gmail.com', 'VelikiVucko', 'citalac'),
(11, 'Ime', 'Prezime', 'validan.email@example.com', 'validnaSifra', 'citalac'),
(13, 'Limeni', 'Prezime', 'Limeni123@gmail.com', 'validnaSifra123', 'citalac');

-- --------------------------------------------------------

--
-- Table structure for table `ocena`
--

CREATE TABLE `ocena` (
  `id` int(11) NOT NULL,
  `ocena` int(11) NOT NULL,
  `id_knjige` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ocena`
--

INSERT INTO `ocena` (`id`, `ocena`, `id_knjige`) VALUES
(10, 3, 1),
(11, 3, 1),
(12, 4, 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `knjige`
--
ALTER TABLE `knjige`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `naslov` (`naslov`,`autor`),
  ADD KEY `fk_ocena` (`ocena_id`),
  ADD KEY `fk_komentari` (`komentari_id`);

--
-- Indexes for table `komentari`
--
ALTER TABLE `komentari`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_knjige` (`id_knjige`);

--
-- Indexes for table `korisnici`
--
ALTER TABLE `korisnici`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `ocena`
--
ALTER TABLE `ocena`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_knjige` (`id_knjige`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `knjige`
--
ALTER TABLE `knjige`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `komentari`
--
ALTER TABLE `komentari`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `korisnici`
--
ALTER TABLE `korisnici`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `ocena`
--
ALTER TABLE `ocena`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `knjige`
--
ALTER TABLE `knjige`
  ADD CONSTRAINT `fk_komentari` FOREIGN KEY (`komentari_id`) REFERENCES `komentari` (`id`),
  ADD CONSTRAINT `fk_ocena` FOREIGN KEY (`ocena_id`) REFERENCES `ocena` (`id`);

--
-- Constraints for table `komentari`
--
ALTER TABLE `komentari`
  ADD CONSTRAINT `komentari_ibfk_1` FOREIGN KEY (`id_knjige`) REFERENCES `knjige` (`id`);

--
-- Constraints for table `ocena`
--
ALTER TABLE `ocena`
  ADD CONSTRAINT `ocena_ibfk_1` FOREIGN KEY (`id_knjige`) REFERENCES `knjige` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
