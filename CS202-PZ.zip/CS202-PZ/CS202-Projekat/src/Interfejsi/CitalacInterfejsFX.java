package Interfejsi;

import PreuzimanjeSaStranice.PreuzmiInfoIzOl;
import klase.Knjiga;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CitalacInterfejsFX extends Application {

    private static final String URL = "jdbc:mysql://localhost:3306/gradske_biblioteke";
    private static final String KORISNICKO_IME = "root";
    private static final String SIFRA = "";

    private TableView<Knjiga> tabelaKnjiga;
    private ComboBox<String> comboBoxZanrovi;
    private Button dugmeSortiraj, dugmeOceni;
    private TextArea textAreaKomentar;
    private Label infoLabel;
    private TextField ocenaTextField;
private TextField komentarTextField;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Interfejs za čitaoca");

        BorderPane borderPane = new BorderPane();
        Scene scene = new Scene(borderPane, 800, 700);

        tabelaKnjiga = createTable();
        borderPane.setCenter(tabelaKnjiga);

        infoLabel = prikaziInformacije();
        borderPane.setTop(infoLabel);

        HBox hbox = createHBox();
        borderPane.setBottom(hbox);

        PreuzmiInfoIzOl preuzmiInfoIzOl = new PreuzmiInfoIzOl();
        String infoText = "Sta su knjige:\n" + preuzmiInfoIzOl.preuzmiInfo();
        infoLabel.setText(infoText);

        primaryStage.setScene(scene);
        primaryStage.show();

        popuniTabeluKnjigama();
    }

    private Label prikaziInformacije() {
        Label infoLabel = new Label("Lista najboljih knjiga:");
        return infoLabel;
    }

    private TableView<Knjiga> createTable() {
        TableView<Knjiga> table = new TableView<>();
        table.setEditable(false);

        TableColumn<Knjiga, String> naslovColumn = new TableColumn<>("Naslov");
        naslovColumn.setCellValueFactory(new PropertyValueFactory<>("naslov"));

        TableColumn<Knjiga, String> autorColumn = new TableColumn<>("Autor");
        autorColumn.setCellValueFactory(new PropertyValueFactory<>("autor"));

        TableColumn<Knjiga, String> zanrColumn = new TableColumn<>("Žanr");
        zanrColumn.setCellValueFactory(new PropertyValueFactory<>("zanr"));

        TableColumn<Knjiga, Integer> brojStranaColumn = new TableColumn<>("Broj Strana");
        brojStranaColumn.setCellValueFactory(new PropertyValueFactory<>("brojStrana"));

        TableColumn<Knjiga, Integer> ocenaColumn = new TableColumn<>("Ocena");
        ocenaColumn.setCellValueFactory(new PropertyValueFactory<>("ocena"));

        TableColumn<Knjiga, String> komentarColumn = new TableColumn<>("Komentar");
        komentarColumn.setCellValueFactory(new PropertyValueFactory<>("komentar"));

        table.getColumns().addAll(naslovColumn, autorColumn, zanrColumn, brojStranaColumn, ocenaColumn, komentarColumn);

        return table;
    }

   private HBox createHBox() {
    HBox hbox = new HBox();
    hbox.setPadding(new Insets(10, 10, 10, 10));
    hbox.setSpacing(10);

    // Polje za unos ocene
    TextField ocenaTextField = new TextField();
    ocenaTextField.setPromptText("Ocena");

    // Polje za unos komentara
    TextField komentarTextField = new TextField();
    komentarTextField.setPromptText("Unesite komentar...");

    // Dugme za davanje ocene
    Button dugmeDajOcenu = new Button("Daj ocenu");
    dugmeDajOcenu.setOnAction(e -> oceniKnjigu(ocenaTextField.getText()));

    // Dugme za ostavljanje komentara
    Button dugmeOstaviKomentar = new Button("Ostavi komentar");
    dugmeOstaviKomentar.setOnAction(e -> ostaviKomentar(komentarTextField.getText()));

    hbox.getChildren().addAll(ocenaTextField, dugmeDajOcenu, komentarTextField, dugmeOstaviKomentar);

    return hbox;
}

    private void popuniTabeluKnjigama() {
        ObservableList<Knjiga> listaKnjiga = FXCollections.observableArrayList();

        try (Connection connection = DriverManager.getConnection(URL, KORISNICKO_IME, SIFRA);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT Knjige.*, Ocena.ocena, Komentari.tekst FROM Knjige " +
                     "LEFT JOIN Ocena ON Knjige.id = Ocena.id_knjige " +
                     "LEFT JOIN Komentari ON Knjige.id = Komentari.id_knjige")) {

            while (resultSet.next()) {
                String naslov = resultSet.getString("naslov");
                String autor = resultSet.getString("autor");
                String zanr = resultSet.getString("zanr");
                int brojStrana = resultSet.getInt("broj_strana");
                int ocena = resultSet.getInt("ocena");
                String komentar = resultSet.getString("tekst");

                Knjiga knjiga = new Knjiga(naslov, autor, zanr, brojStrana, ocena, komentar);
                listaKnjiga.add(knjiga);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        tabelaKnjiga.setItems(listaKnjiga);
    }

   private void oceniKnjigu(String ocenaText) {
    if (!ocenaText.isEmpty()) {
        try {
            int ocena = Integer.parseInt(ocenaText);
            if (ocena >= 1 && ocena <= 5) {
                Knjiga selectedKnjiga = tabelaKnjiga.getSelectionModel().getSelectedItem();
                if (selectedKnjiga != null) {
                    selectedKnjiga.setOcena(ocena);
                    tabelaKnjiga.refresh();
                    
                    try (Connection connection = DriverManager.getConnection(URL, KORISNICKO_IME, SIFRA);
                        PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Ocena (ocena, id_knjige) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                       preparedStatement.setInt(1, ocena);
                       preparedStatement.setInt(2, selectedKnjiga.getId());
                       preparedStatement.executeUpdate();

                       ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                       if (generatedKeys.next()) {
                           int ocenaId = generatedKeys.getInt(1);
                           // Sada imate ocenaId koji možete koristiti
                       } else {
                           // U slučaju da nije vraćen generisani ključ
                           prikaziGresku("Nije moguće dobiti generisani ključ za ocenu.");
                       }
                   } catch (SQLException ex) {
                       ex.printStackTrace();
                       prikaziGresku("Greška prilikom upisa ocene u bazu podataka.");
                   }
                } else {
                    prikaziGresku("Molimo odaberite knjigu iz tabele.");
                }
            } else {
                prikaziGresku("Ocena mora biti u opsegu od 1 do 5.");
            }
        } catch (NumberFormatException ex) {
            prikaziGresku("Neispravan format ocene. Unesite broj.");
        }
    } else {
        prikaziGresku("Molimo unesite ocenu.");
    }
}


private void ostaviKomentar(String komentar) {
    if (!komentar.isEmpty()) {
        Knjiga selectedKnjiga = tabelaKnjiga.getSelectionModel().getSelectedItem();
        if (selectedKnjiga != null) {
            selectedKnjiga.setKomentar(komentar);
            tabelaKnjiga.refresh();
            try (Connection connection = DriverManager.getConnection(URL, KORISNICKO_IME, SIFRA);
                 Statement statement = connection.createStatement()) {
                String insertQuery = String.format("INSERT INTO Komentar (tekst_komentara, id_knjige) VALUES ('%s', %d)", komentar, selectedKnjiga.getId());
                statement.executeUpdate(insertQuery);
            } catch (Exception ex) {
                ex.printStackTrace();
                prikaziGresku("Greška prilikom upisa komentara u bazu podataka.");
            }
        } else {
            prikaziGresku("Molimo odaberite knjigu iz tabele.");
        }
    } else {
        prikaziGresku("Molimo unesite komentar.");
    }
}


    private void prikaziGresku(String poruka) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Greška");
        alert.setHeaderText(null);
        alert.setContentText(poruka);
        alert.showAndWait();
    }
}
