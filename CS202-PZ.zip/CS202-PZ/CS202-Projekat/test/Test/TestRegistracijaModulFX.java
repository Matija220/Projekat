/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;
import Exception.NeuspesnaRegistracijaException;
import Exception.PraznoPoljeException;
import Moduli.RegistracijaModulFX;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class TestRegistracijaModulFX {

    @BeforeClass
    public static void inicijalizacija() {
        // Inicijalizacija resursa, ako je potrebno
    }

    @Test
    public void testUspesneRegistracije() {
        try {
            assertTrue(RegistracijaModulFX.registrujCitaoca("Limeni", "Prezime", "Limeni123@gmail.com", "validnaSifra123"));
        } catch (NeuspesnaRegistracijaException | PraznoPoljeException e) {
            fail("Neočekivana greška: " + e.getMessage());
        }
    }

    @Test
    public void testRegistracijeSaNevalidnimEmailom() {
        try {
            assertFalse(RegistracijaModulFX.registrujCitaoca("Ime", "Prezime", "nevalidan.email", "validnaSifra"));
        } catch (NeuspesnaRegistracijaException | PraznoPoljeException e) {
            assertEquals("Nevažeći podaci. Proverite unos.", e.getMessage());
        }
    }

    @Test
    public void testRegistracijeSaPraznimPoljem() {
        try {
            assertFalse(RegistracijaModulFX.registrujCitaoca("", "Prezime", "validan.email@example.com", "validnaSifra"));
        } catch (NeuspesnaRegistracijaException | PraznoPoljeException e) {
            assertEquals("Nevažeći podaci. Proverite unos.", e.getMessage());
        }
    }

    @Test
    public void testRegistracijeSaKratkomSifrom() {
        try {
            assertFalse(RegistracijaModulFX.registrujCitaoca("Ime", "Prezime", "validan.email@example.com", "kratka"));
        } catch (NeuspesnaRegistracijaException | PraznoPoljeException e) {
            assertEquals("Nevažeći podaci. Proverite unos.", e.getMessage());
        }
    }

}





