/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

public class Ocena {
    private int id;
    private String ocena;
    private int idKnjige;

    public Ocena() {
        this(0, null, 0);
    }

    public Ocena(int id, String ocena, int idKnjige) {
        this.id = id;
        this.ocena = ocena;
        this.idKnjige = idKnjige;
    }

    // Getter methods
    public int getId() {
        return id;
    }

    public String getOcena() {
        return ocena;
    }

    public int getIdKnjige() {
        return idKnjige;
    }

    // Setter methods
    public void setId(int id) {
        this.id = id;
    }

    public void setOcena(String ocena) {
        this.ocena = ocena;
    }

    public void setIdKnjige(int idKnjige) {
        this.idKnjige = idKnjige;
    }

    // toString method
    @Override
    public String toString() {
        return "Ocena{" +
                "id=" + id +
                ", ocena='" + ocena + '\'' +
                ", idKnjige=" + idKnjige +
                '}';
    }
}
