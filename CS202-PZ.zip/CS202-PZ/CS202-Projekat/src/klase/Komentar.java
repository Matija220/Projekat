
package klase;

public class Komentar {
    private int id;
    private String tekst;
    private int idKnjige;

    public Komentar() {
        this(0, null, 0);
    }

    public Komentar(int id, String tekst, int idKnjige) {
        this.id = id;
        this.tekst = tekst;
        this.idKnjige = idKnjige;
    }

    // Getteri
    public int getId() {
        return id;
    }

    public String getTekst() {
        return tekst;
    }

    public int getIdKnjige() {
        return idKnjige;
    }

    // Setteri
    public void setId(int id) {
        this.id = id;
    }

    public void setTekst(String tekst) {
        this.tekst = tekst;
    }

    public void setIdKnjige(int idKnjige) {
        this.idKnjige = idKnjige;
    }

    @Override
    public String toString() {
        return "Komentar{" +
                "id=" + id +
                ", tekst='" + tekst + '\'' +
                ", idKnjige=" + idKnjige +
                '}';
    }
}


