/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package klase;

import klase.Knjiga;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TabelaKnjiga {

    private static final String URL = "jdbc:mysql://localhost:3306/gradske_biblioteke";
    private static final String KORISNICKO_IME = "root";
    private static final String SIFRA = "";

    public static void popuniTabeluKnjigama(TableView<Knjiga> tabelaKnjiga) {
        ObservableList<Knjiga> listaKnjiga = FXCollections.observableArrayList();

        try (Connection connection = DriverManager.getConnection(URL, KORISNICKO_IME, SIFRA);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT Knjige.*, Ocena.ocena FROM Knjige LEFT JOIN Ocena ON Knjige.id = Ocena.id_knjige")) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String naslov = resultSet.getString("naslov");
                String autor = resultSet.getString("autor");
                String zanr = resultSet.getString("zanr");
                int brojStrana = resultSet.getInt("broj_strana");
                int ocena = resultSet.getInt("ocena");

                Knjiga knjiga = new Knjiga(id, naslov, autor, zanr, brojStrana, ocena);
                listaKnjiga.add(knjiga);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        }

        tabelaKnjiga.setItems(listaKnjiga);
        System.out.println("Tabela popunjena");
    }
}
