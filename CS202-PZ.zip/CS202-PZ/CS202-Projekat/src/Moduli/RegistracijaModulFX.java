/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Moduli;

import Exception.PraznoPoljeException;
import Exception.NeuspesnaRegistracijaException;
import javafx.scene.control.Alert;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class RegistracijaModulFX {

    private static final String URL = "jdbc:mysql://localhost:3306/gradske_biblioteke";
    private static final String KORISNICKO_IME = "root";
    private static final String SIFRA = "";

    private static final String EMAIL_REGEX = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

    public static boolean registrujCitaoca(String ime, String prezime, String email, String sifra) throws NeuspesnaRegistracijaException, PraznoPoljeException {
    if (!validirajEmail(email) || !validirajIme(ime) || !validirajPrezime(prezime) || !validirajSifru(sifra)) {
        throw new NeuspesnaRegistracijaException("Nevažeći podaci. Proverite unos.");
    }

    String upit = "INSERT INTO korisnici (ime, prezime, email, sifra, uloga) VALUES (?, ?, ?, ?, 'citalac')";

    try (
        Connection connection = DriverManager.getConnection(URL, KORISNICKO_IME, SIFRA);
        PreparedStatement preparedStatement = connection.prepareStatement(upit)
    ) {
        preparedStatement.setString(1, ime);
        preparedStatement.setString(2, prezime);
        preparedStatement.setString(3, email);
        preparedStatement.setString(4, sifra);

        int affectedRows = preparedStatement.executeUpdate();
        if (affectedRows <= 0) {
            throw new NeuspesnaRegistracijaException("Registracija nije uspela.");
        } else {
            return true; // Vratite true ako je registracija uspešna
        }

    } catch (SQLException e) {
        e.printStackTrace();
        throw new NeuspesnaRegistracijaException("Greška prilikom registracije.");
    }
}


    private static boolean validirajEmail(String email) {
        return Pattern.matches(EMAIL_REGEX, email);
    }

    private static boolean validirajIme(String ime) {
        // Dodajte dodatne provere po potrebi
        return ime.length() > 0;
    }

    private static boolean validirajPrezime(String prezime) {
        // Dodajte dodatne provere po potrebi
        return prezime.length() > 0;
    }

    private static boolean validirajSifru(String sifra) throws PraznoPoljeException {
        if (sifra.isEmpty()) {
            throw new PraznoPoljeException("Šifra");
        }
        return sifra.length() > 7;
    }

    private static void prikaziInformaciju(String poruka) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informacija");
        alert.setHeaderText(null);
        alert.setContentText(poruka);
        alert.showAndWait();
    }

    private static void prikaziGresku(String poruka) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Greška");
        alert.setHeaderText(null);
        alert.setContentText(poruka);
        alert.showAndWait();
    }
}

