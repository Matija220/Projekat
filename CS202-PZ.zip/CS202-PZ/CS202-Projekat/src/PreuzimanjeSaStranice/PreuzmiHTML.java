/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PreuzimanjeSaStranice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PreuzmiHTML {

    public static String preuzmiHTML(String url) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setRequestMethod("GET");

        int responseCode = connection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder html = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                html.append(line).append("\n");
            }

            reader.close();
            return html.toString();
        } else {
            throw new IOException("HTTP zahtev nije uspeo, HTTP kod odgovora: " + responseCode);
        }
    }

    public static void main(String[] args) {
        try {
            String url = "https://sr.wikipedia.org/sr-el/%D0%9A%D1%9A%D0%B8%D0%B3%D0%B0";
            String html = preuzmiHTML(url);

            // Ovde možete raditi šta želite sa preuzetim HTML-om
            System.out.println(html);
        } catch (IOException e) {
            e.printStackTrace();
            // Obrada grešaka
        }
    }
}
