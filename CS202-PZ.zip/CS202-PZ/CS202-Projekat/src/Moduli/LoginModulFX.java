/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Moduli;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class LoginModulFX extends Application {

    static final String URL = "jdbc:mysql://localhost:3306/gradske_biblioteke";
    static final String KORISNICKO_IME = "root";
    static final String SIFRA = "";

    static final String EMAIL_REGEX = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    private TextField emailTextField;
    private PasswordField sifraPasswordField;


    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Login Modul");

        GridPane gridPane = createGridPane();
        Button prijaviSeButton = new Button("Prijavi se");

        prijaviSeButton.setOnAction(e -> prijaviKorisnika());

        gridPane.add(prijaviSeButton, 1, 2);

        Scene scene = new Scene(gridPane, 300, 150);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private GridPane createGridPane() {
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setVgap(8);
        gridPane.setHgap(10);

        Label emailLabel = new Label("Email:");
        GridPane.setConstraints(emailLabel, 0, 0);

        emailTextField = new TextField();
        emailTextField.setPromptText("Unesite email");
        GridPane.setConstraints(emailTextField, 1, 0);

        Label sifraLabel = new Label("Šifra:");
        GridPane.setConstraints(sifraLabel, 0, 1);

        sifraPasswordField = new PasswordField();
        sifraPasswordField.setPromptText("Unesite šifru");
        GridPane.setConstraints(sifraPasswordField, 1, 1);

        gridPane.getChildren().addAll(emailLabel, emailTextField, sifraLabel, sifraPasswordField);

        return gridPane;
    }

    private void prijaviKorisnika() {
        String email = emailTextField.getText();
        String sifra = sifraPasswordField.getText();

        String uloga = LoginModul.prijaviKorisnika(email, sifra);

        if (uloga != null) {
            prikaziInformaciju("Korisnik sa ulogom: " + uloga + " je uspešno prijavljen.");
        } else {
            prikaziInformaciju("Prijavljivanje nije uspelo. Proverite unos.");
        }
    }

    private static void prikaziInformaciju(String poruka) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informacija");
        alert.setHeaderText(null);
        alert.setContentText(poruka);
        alert.showAndWait();
    }
}

class LoginModul {

    public static String prijaviKorisnika(String email, String sifra) {
        if (!validirajEmail(email) || !validirajLozinku(sifra)) {
            return null;
        }

        String upit = "SELECT uloga FROM korisnici WHERE email = ? AND sifra = ?";

        try (
                Connection connection = DriverManager.getConnection(LoginModulFX.URL, LoginModulFX.KORISNICKO_IME, LoginModulFX.SIFRA);
                PreparedStatement preparedStatement = connection.prepareStatement(upit)
        ) {
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, sifra);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getString("uloga");
            } else {
                return null;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static boolean validirajEmail(String email) {
        return Pattern.matches(LoginModulFX.EMAIL_REGEX, email);
    }

    private static boolean validirajLozinku(String sifra) {
        return sifra.length() > 7;
    }
}
