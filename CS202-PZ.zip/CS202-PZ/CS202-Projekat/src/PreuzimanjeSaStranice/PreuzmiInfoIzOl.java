/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PreuzimanjeSaStranice;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

public class PreuzmiInfoIzOl {

    public String preuzmiInfo() {
        try {
            String url = "https://sr.wikipedia.org/sr-el/%D0%9A%D1%9A%D0%B8%D0%B3%D0%B0";
            String html = PreuzmiHTML.preuzmiHTML(url);

            // Analiza HTML-a pomoću JSoup
            Document document = Jsoup.parse(html);

            // Selektujte prvi paragraf na stranici
            Element paragrafElement = document.select("p").first();

            // Uzmi tekst paragrafa
            String tekstParagrafa = paragrafElement.text();

            // Podeli tekst na više redova svaki puta kada se pojavi razmak nakon 100 karaktera
            StringBuilder rezultat = new StringBuilder();
            int duzina = 100;
            for (int i = 0; i < tekstParagrafa.length(); i += duzina) {
                if (i + duzina < tekstParagrafa.length()) {
                    rezultat.append(tekstParagrafa.substring(i, i + duzina)).append("\n");
                } else {
                    rezultat.append(tekstParagrafa.substring(i)).append("\n");
                }
            }

            // Vrati rezultat
            return rezultat.toString();
        } catch (IOException e) {
            e.printStackTrace();
            // Obrada grešaka
            return "Greška prilikom preuzimanja informacija";
        }
    }

    public static void main(String[] args) {
        PreuzmiInfoIzOl preuzmiInfoIzOl = new PreuzmiInfoIzOl();
        String info = preuzmiInfoIzOl.preuzmiInfo();
        System.out.println(info);
    }
}



