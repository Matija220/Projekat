package Interfejsi;

import Exception.NeuspesnoDodavanjeKnjigeException;
import klase.Knjiga;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.sql.*;
import java.util.Optional;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

public class BibliotekarInterfejs extends Application {

    private static final String URL = "jdbc:mysql://localhost:3306/gradske_biblioteke";
    private static final String KORISNICKO_IME = "root";
    private static final String SIFRA = "";

    private TextField poljeNaslov, poljeAutor, poljeZanr, poljeBrojStrana, poljeId;
    private TableView<Knjiga> tabelaKnjiga;
    private ObservableList<Knjiga> listaKnjiga;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Bibliotekar Interfejs");

        poljeId = new TextField();
        poljeNaslov = new TextField();
        poljeAutor = new TextField();
        poljeZanr = new TextField();
        poljeBrojStrana = new TextField();

        tabelaKnjiga = createTable();
        listaKnjiga = FXCollections.observableArrayList();
        tabelaKnjiga.setItems(listaKnjiga);

        Button dugmeDodajKnjigu = new Button("Dodaj knjigu");
        Button dugmeObrisiKnjigu = new Button("Obrisi knjigu");

        dugmeDodajKnjigu.setOnAction(e -> dodajKnjigu());
        dugmeObrisiKnjigu.setOnAction(e -> obrisiKnjigu());

        BorderPane borderPane = new BorderPane();

        GridPane gridPane = createGridPane();
        GridPane gridPaneId = createGridPaneId();

        borderPane.setCenter(gridPane);
        borderPane.setBottom(gridPaneId);

        borderPane.setTop(new ScrollPane(tabelaKnjiga));

        borderPane.setRight(new VBox(10, dugmeDodajKnjigu, dugmeObrisiKnjigu));

        Scene scene = new Scene(borderPane, 800, 600);

        primaryStage.setScene(scene);
        primaryStage.show();

        popuniTabeluKnjigama();
    }

    private GridPane createGridPane() {
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setVgap(8);
        gridPane.setHgap(10);

        gridPane.add(new Label("Naslov:"), 0, 0);
        gridPane.add(poljeNaslov, 1, 0);
        gridPane.add(new Label("Autor:"), 0, 1);
        gridPane.add(poljeAutor, 1, 1);
        gridPane.add(new Label("Žanr:"), 0, 2);
        gridPane.add(poljeZanr, 1, 2);
        gridPane.add(new Label("Broj strana:"), 0, 3);
        gridPane.add(poljeBrojStrana, 1, 3);

        return gridPane;
    }

    private GridPane createGridPaneId() {
        GridPane gridPaneId = new GridPane();
        gridPaneId.setPadding(new Insets(10, 10, 10, 10));
        gridPaneId.setVgap(8);
        gridPaneId.setHgap(10);

       

        return gridPaneId;
    }

    private void dodajKnjigu() {
        try {
            Knjiga novaKnjiga = kreirajKnjigu();
            if (novaKnjiga != null) {
                novaKnjiga.dodajKnjigu();
                popuniTabeluKnjigama();
            }
        } catch (NeuspesnoDodavanjeKnjigeException ex) {
            prikaziGresku("Greška prilikom dodavanja knjige.");
        }
    }

    private void obrisiKnjigu() {
    Knjiga selektovanaKnjiga = tabelaKnjiga.getSelectionModel().getSelectedItem();
    if (selektovanaKnjiga != null) {
        selektovanaKnjiga.obrisiKnjigu();
        popuniTabeluKnjigama();
    } else {
        prikaziGresku("Nije selektovana knjiga za brisanje.");
    }
}

    private TableView<Knjiga> createTable() {
        TableView<Knjiga> table = new TableView<>();
        table.setEditable(false);

        TableColumn<Knjiga, String> naslovColumn = new TableColumn<>("Naslov");
        naslovColumn.setCellValueFactory(new PropertyValueFactory<>("naslov"));

        TableColumn<Knjiga, String> autorColumn = new TableColumn<>("Autor");
        autorColumn.setCellValueFactory(new PropertyValueFactory<>("autor"));

        TableColumn<Knjiga, String> zanrColumn = new TableColumn<>("Žanr");
        zanrColumn.setCellValueFactory(new PropertyValueFactory<>("zanr"));

        TableColumn<Knjiga, Integer> brojStranaColumn = new TableColumn<>("Broj Strana");
        brojStranaColumn.setCellValueFactory(new PropertyValueFactory<>("brojStrana"));

        table.getColumns().addAll(naslovColumn, autorColumn, zanrColumn, brojStranaColumn);

        return table;
    }

    private void popuniTabeluKnjigama() {
        listaKnjiga.clear();
        try (Connection connection = DriverManager.getConnection(URL, KORISNICKO_IME, SIFRA);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM Knjige")) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String naslov = resultSet.getString("naslov");
                String autor = resultSet.getString("autor");
                String zanr = resultSet.getString("zanr");
                int brojStrana = resultSet.getInt("broj_strana");

                Knjiga knjiga = new Knjiga(id, naslov, autor, zanr, brojStrana);
                listaKnjiga.add(knjiga);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            prikaziGresku("Greška prilikom popunjavanja tabele knjiga.");
        }
    }

    private Knjiga kreirajKnjigu() {
        String naslov = poljeNaslov.getText();
        String autor = poljeAutor.getText();
        String zanr = poljeZanr.getText();
        int brojStrana = Integer.parseInt(poljeBrojStrana.getText());

        if (naslov.isEmpty() || autor.isEmpty() || zanr.isEmpty() || brojStrana <= 0) {
            prikaziGresku("Sva polja moraju biti popunjena i broj strana mora biti pozitivan broj.");
            return null;
        }

        return new Knjiga(naslov, autor, zanr, brojStrana);
    }

    private void prikaziGresku(String poruka) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Greška");
        alert.setHeaderText(null);
        alert.setContentText(poruka);
        alert.showAndWait();
    }
}
