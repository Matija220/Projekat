/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klase;

import Exception.NeuspesnoCitavanjeIzBazeException;
import Exception.NeuspesnoDodavanjeKnjigeException;
import javafx.collections.ObservableList;
import java.sql.*;

public class KnjigaDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/gradske_biblioteke";
    private static final String KORISNICKO_IME = "root";
    private static final String SIFRA = "";

    public static void dodajKnjigu(Knjiga knjiga) throws NeuspesnoDodavanjeKnjigeException {
        try (Connection connection = DriverManager.getConnection(URL, KORISNICKO_IME, SIFRA)) {
            String upit = "INSERT INTO knjige (naslov, autor, zanr, broj_strana) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(upit, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, knjiga.getNaslov());
                preparedStatement.setString(2, knjiga.getAutor());
                preparedStatement.setString(3, knjiga.getZanr());
                preparedStatement.setInt(4, knjiga.getBrojStrana());

                preparedStatement.executeUpdate();

                try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        knjiga.setId(generatedKeys.getInt(1));
                    } else {
                        throw new NeuspesnoDodavanjeKnjigeException("Nije moguće dobiti generisani ID nakon dodavanja knjige.");
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new NeuspesnoDodavanjeKnjigeException("Greška prilikom dodavanja knjige.", ex);
        }
    }

    public static void obrisiKnjigu(Knjiga knjiga) throws NeuspesnoBrisanjeKnjigeException {
        try (Connection connection = DriverManager.getConnection(URL, KORISNICKO_IME, SIFRA)) {
            String upit = "DELETE FROM knjige WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(upit)) {
                preparedStatement.setInt(1, knjiga.getId());
                int affectedRows = preparedStatement.executeUpdate();
                if (affectedRows == 0) {
                    prikaziGresku("Nije moguće pronaći knjigu sa datim ID-om.");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            prikaziGresku("Greška prilikom brisanja knjige.");
        }
    }

    public static void prikaziSveKnjige(ObservableList<Knjiga> listaKnjiga) throws NeuspesnoCitavanjeIzBazeException {
        try (Connection connection = DriverManager.getConnection(URL, KORISNICKO_IME, SIFRA)) {
            String upit = "SELECT * FROM knjige";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(upit)) {
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String naslov = resultSet.getString("naslov");
                    String autor = resultSet.getString("autor");
                    String zanr = resultSet.getString("zanr");
                    int brojStrana = resultSet.getInt("broj_strana");
                    int ocena = resultSet.getInt("ocena");
                    String komentar = resultSet.getString("komentar");
                    Knjiga knjiga = new Knjiga(id, naslov, autor, zanr, brojStrana, ocena, komentar);
                    listaKnjiga.add(knjiga);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new NeuspesnoCitavanjeIzBazeException("Greška prilikom čitanja knjiga iz baze podataka.");
        }
    }

    private static void prikaziGresku(String poruka) {
        // Implementirajte prikazivanje greške na korisničkom interfejsu
    }
}
